import shutil
filepath = '/Users/charanjeetsingh/Documents/PythonProjects/Python_ Experiments/files/'

shutil.make_archive('Files_zip', 'zip', filepath)
